#import <UIKit/UIKit.h>

//! Project version number for SignedCallSDK.
FOUNDATION_EXPORT double SignedCallSDKVersionNumber;

//! Project version string for SignedCallSDK.
FOUNDATION_EXPORT const unsigned char SignedCallSDKVersionString[];
