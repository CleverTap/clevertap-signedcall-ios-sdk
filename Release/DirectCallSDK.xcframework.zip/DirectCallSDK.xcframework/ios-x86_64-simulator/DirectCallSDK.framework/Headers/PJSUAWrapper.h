@import ct_pjsua;
#import <AVFoundation/AVFoundation.h>

@interface PJSUAWrapper :NSObject {
    
    pj_status_t status;
    AVAudioPlayer* audioPlayer;
    char * UsercallID;
    NSString * UserID;
    int count;
    
}

@property(nonatomic,assign)   pjsua_call_id call_id;

// The hooks for our plugin commands
- (NSString *) start: (NSString *)phone withHost:(NSString*) callSockHost withMode: (BOOL)staging withCredData: (NSString *)credData;
- (void) stop;
- (void) hangup;
- (void) mute;
- (void) unmute;
- (void) speakeron;
- (void) speakeroff;
- (void) playRingtone;

void answercall(void);
@end
