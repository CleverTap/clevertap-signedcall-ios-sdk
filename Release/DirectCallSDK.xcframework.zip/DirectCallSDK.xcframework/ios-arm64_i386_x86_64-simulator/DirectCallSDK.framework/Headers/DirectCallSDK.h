#import <UIKit/UIKit.h>

//! Project version number for PatchFramework.
FOUNDATION_EXPORT double DirectCallSDKVersionNumber;

//! Project version string for PatchFramework.
FOUNDATION_EXPORT const unsigned char DirectCallSDKVersionString[];
